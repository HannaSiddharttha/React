export default{
     apiKey: "AIzaSyCM_6EBeIn2Qmr31yWAXBEu4UL8kjfQCsE",
    authDomain: "modelo-d5e9b.firebaseapp.com",
    projectId: "modelo-d5e9b",
    storageBucket: "modelo-d5e9b.appspot.com",
    messagingSenderId: "844773683059",
    appId: "1:844773683059:web:a7c51486894ecf256c1f06"
}