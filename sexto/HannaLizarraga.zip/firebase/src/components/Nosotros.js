import React from 'react'


export const Nosotros = () => (

     <div className="Nosotros">

        <img src="/images/Nosotros.png"/>
    </div>

    
)