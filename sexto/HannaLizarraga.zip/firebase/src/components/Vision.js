import React from 'react'

export const Vision = () => (

     <div className="Vision">

        <img src="/images/vision2.png"/>
    </div>
)