import React from 'react'
export const Planes = () => (

   
     <div className="Planes">

        <img src="/images/planes.png"/>
    </div>
    
)
      