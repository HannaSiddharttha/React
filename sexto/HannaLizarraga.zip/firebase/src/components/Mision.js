import React from 'react'

export const Mision = () => (


    <div className="Mision">
    
        <img src="/images/mision.png"/>
    </div>
         
   
)