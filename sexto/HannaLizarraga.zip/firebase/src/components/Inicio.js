import React from 'react'
import './styles/Inicio.css'
export const Inicio = () => (

   <div className="Inicio">
        <img src="/images/home.png"/>
    </div>
  
)